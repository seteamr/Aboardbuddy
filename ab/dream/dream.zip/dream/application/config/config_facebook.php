<?php
$config['appID']    = '323060248299694';
$config['appSecret']    = 'af313784b33efa77cb272fff1dac7d1c';
?>
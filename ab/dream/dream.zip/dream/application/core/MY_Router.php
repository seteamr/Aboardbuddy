<?php

(defined('BASEPATH')) or exit('No direct script access allowed');



/* load the HMVC_Router class */

require APPPATH . 'third_party/HMVC/Router.php';
class MY_Router extends HMVC_Router {
    

}